/* ==========================================================================
   RIDDHII GALA — interactions
   Reads products and the collection structure from Supabase (see
   assets/supabase-client.js and supabase/schema.sql). Depends on
   SILHOUETTES from assets/silhouettes.js as a fallback when a product has
   no uploaded photo, and on the Supabase JS SDK + supabaseClient being
   loaded before this file.
   ========================================================================== */
(function () {
  "use strict";

  let whatsappNumber = "917977097990"; // overwritten by site_settings once loaded
  const NOT_CONFIGURED = String(SUPABASE_URL).includes("YOUR-PROJECT-REF");
  const NOTIFY_ENQUIRY_URL = `${SUPABASE_URL}/functions/v1/notify-enquiry`;

  const grid = document.getElementById("product-grid");
  const sidebar = document.getElementById("sidebar");
  const menuToggle = document.querySelector(".menu-toggle");
  const modal = document.getElementById("product-modal");
  const modalContent = document.getElementById("modal-content");
  const modalClose = modal ? modal.querySelector(".close") : null;

  let currentFilter = "featured";
  let filterButtons = [];
  let navLinks = [];
  let searchResults = null;
  const searchInput = document.getElementById("site-search-input");
  const searchClear = document.getElementById("site-search-clear");

  /* ---------------- setup guard ---------------- */

  if (NOT_CONFIGURED) {
    if (grid) {
      grid.innerHTML = `<div class="grid-empty">Site isn't connected to its database yet — add your Supabase project URL and key to assets/supabase-client.js.</div>`;
    }
  }

  /* ---------------- category / filter key helpers ---------------- */
  function groupFilterKey(g) { return g.id; }
  function childFilterKey(g, c) { return c.id; }

  /* ---------------- sidebar nav ---------------- */

  async function fetchCategoryData() {
    const [groupsRes, childrenRes, standaloneRes, comingSoonRes] = await Promise.all([
      supabaseClient.from("category_groups").select("*").order("sort_order"),
      supabaseClient.from("category_children").select("*").order("sort_order"),
      supabaseClient.from("standalone_filters").select("*").order("sort_order"),
      supabaseClient.from("coming_soon").select("*").order("sort_order"),
    ]);
    const groups = (groupsRes.data || []).map((g) => ({
      ...g,
      children: (childrenRes.data || []).filter((c) => c.group_id === g.id),
    }));
    return {
      groups,
      standalone: standaloneRes.data || [],
      comingSoon: comingSoonRes.data || [],
    };
  }

  function renderSidebarNav({ groups, standalone, comingSoon }) {
    const collectionsNav = document.getElementById("collections-nav");
    const standaloneWrap = document.getElementById("standalone-filters");
    if (!collectionsNav && !standaloneWrap) return;

    if (collectionsNav) {
      const groupsHtml = groups
        .map((g) => {
          if (g.children && g.children.length) {
            const childrenHtml = g.children
              .map((c) => `<button data-filter="${childFilterKey(g, c)}">${c.label}</button>`)
              .join("");
            return `<details><summary>${g.label}</summary>${childrenHtml}</details>`;
          }
          return `<button data-filter="${groupFilterKey(g)}">${g.label}</button>`;
        })
        .join("");

      const comingSoonHtml = comingSoon
        .map((c) => `<span class="coming-soon">${c.label} <small>coming soon</small></span>`)
        .join("");

      collectionsNav.innerHTML = `<summary>Collections</summary>${groupsHtml}${comingSoonHtml}`;
    }

    if (standaloneWrap) {
      standaloneWrap.innerHTML = standalone
        .map((f) => `<button data-filter="${f.key}">${f.label}</button>`)
        .join("");
    }
  }

  function wireFilterButtons() {
    filterButtons = Array.from(document.querySelectorAll("[data-filter]"));
    filterButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const key = btn.getAttribute("data-filter");
        setActiveFilter(key);
        document.getElementById("collections")?.scrollIntoView({ behavior: "smooth" });
        closeSidebarOnMobile();
      });
    });
  }

  /* ---------------- site settings (WhatsApp number) ---------------- */

  async function loadSiteSettings() {
    const { data, error } = await supabaseClient.from("site_settings").select("*").eq("id", 1).maybeSingle();
    if (error || !data) return;
    if (data.whatsapp_number) whatsappNumber = data.whatsapp_number;
    applyWhatsappLinks();
    applyHeroImage(data.hero_image_url);
  }

  function applyHeroImage(url) {
    const heroArt = document.getElementById("hero-art");
    if (!heroArt || !url) return;
    heroArt.classList.add("has-image");
    heroArt.innerHTML = `<img src="${url}" alt="Riddhii Gala editorial couture" />`;
  }

  function applyWhatsappLinks() {
    const text = "Hello RIDDHII GALA, I would like to enquire.";
    const href = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(text)}`;
    document.getElementById("whatsapp-button")?.setAttribute("href", href);
    document.getElementById("floating-whatsapp")?.setAttribute("href", href);
  }

  /* ---------------- testimonials (Client Love) ---------------- */

  function starString(rating) {
    const n = Math.max(0, Math.min(5, Number(rating) || 0));
    return "★".repeat(n) + "☆".repeat(5 - n);
  }

  async function renderTestimonials() {
    const wrap = document.getElementById("testimonials-grid");
    if (!wrap) return;
    const { data, error } = await supabaseClient
      .from("reviews")
      .select("*")
      .eq("approved", true)
      .order("created_at", { ascending: false });

    if (error || !data || !data.length) {
      wrap.innerHTML = "";
      return;
    }

    wrap.innerHTML = data
      .map(
        (r) => `
      <figure>
        <div style="color:var(--gold);letter-spacing:0.1em;margin-bottom:0.6rem;">${starString(r.rating)}</div>
        <blockquote>"${r.review}"</blockquote>
        ${r.photo_url ? `<img src="${r.photo_url}" alt="${r.name}" loading="lazy" style="width:100%;max-width:220px;aspect-ratio:4/5;object-fit:cover;border-radius:8px;margin-top:.8rem;">` : ""}
        ${r.video_url ? `<video src="${r.video_url}" controls playsinline style="width:100%;max-width:300px;margin-top:.8rem;border-radius:8px;"></video>` : ""}
        <figcaption>— ${r.name}</figcaption>
      </figure>`
      )
      .join("");
  }

  /* ---------------- enquiry form (Contact section) ---------------- */

  function wireEnquiryForm() {
    const form = document.getElementById("custom-order-form");
    const statusEl = document.getElementById("enquiry-status");
    if (!form) return;

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const submitBtn = form.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      statusEl.textContent = "Sending…";

      const payload = {
        name: form.querySelector('[name="name"]').value.trim(),
        whatsapp: form.querySelector('[name="whatsapp"]').value.trim(),
        email: form.querySelector('[name="email"]').value.trim() || null,
        message: form.querySelector('[name="message"]').value.trim(),
        status: "new",
      };

      const { error } = await supabaseClient.from("enquiries").insert(payload);

      if (error) {
        statusEl.textContent = "Something went wrong — please message us on WhatsApp instead.";
        submitBtn.disabled = false;
        return;
      }

      statusEl.textContent = "Thank you — we'll be in touch shortly.";
      form.reset();
      submitBtn.disabled = false;

      // Best-effort email notification — the enquiry above is already
      // safely saved regardless of whether this succeeds, so failures
      // here are silent (logged, not shown to the visitor).
      try {
        await fetch(NOTIFY_ENQUIRY_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify(payload),
        });
      } catch (err) {
        console.warn("Enquiry notification email failed to send:", err);
      }
    });
  }

  /* ---------------- image lightbox (zoom) ---------------- */

  const lightbox = document.getElementById("image-lightbox");
  const lightboxImg = document.getElementById("lightbox-img");
  const lightboxClose = lightbox ? lightbox.querySelector(".close") : null;

  function openLightbox(src, alt) {
    if (!lightbox || !lightboxImg) return;
    lightboxImg.src = src;
    lightboxImg.alt = alt || "";
    if (typeof lightbox.showModal === "function") lightbox.showModal();
    else lightbox.setAttribute("open", "");
  }
  function closeLightbox() {
    if (!lightbox) return;
    if (typeof lightbox.close === "function") lightbox.close();
    else lightbox.removeAttribute("open");
  }
  lightboxClose?.addEventListener("click", closeLightbox);
  lightbox?.addEventListener("click", (e) => {
    if (e.target === lightbox) closeLightbox();
  });

  async function runSiteSearch(term) {
    const q = String(term || "").trim().toLowerCase();
    if (!q) { searchResults = null; return renderGrid(currentFilter); }
    const { data, error } = await supabaseClient.from("products").select("*").eq("status","active");
    if (error) { if(grid) grid.innerHTML='<div class="grid-empty">Search is temporarily unavailable. Please try again or contact us on WhatsApp.</div>'; return; }
    searchResults = (data || []).filter(p => {
      const hay = [p.name,p.collection,p.fabric,p.silhouette,p.description,Array.isArray(p.filters)?p.filters.join(" "):"",Array.isArray(p.key_features)?p.key_features.join(" "):""].join(" ").toLowerCase();
      return hay.includes(q);
    });
    productsCache = searchResults; // openModal() looks products up here — without this, tapping a search result silently did nothing
    currentPage = 1; renderCurrentSearch();
  }
  function renderCurrentSearch(){
    if(!grid || !searchResults) return;
    const items=searchResults;
    grid.innerHTML=items.length ? items.map(p=>`<button class="product-card" type="button" data-id="${p.id}" aria-haspopup="dialog"><span class="card-art">${mediaMarkup(p,"")}</span><span class="card-body"><span class="card-collection">${p.collection||''}</span><h3>${p.name}</h3><p class="card-fabric">${p.fabric||''}</p></span></button>`).join('') : '<div class="grid-empty">No matching pieces found. Try another search or enquire on WhatsApp.</div>';
    grid.querySelectorAll('.product-card').forEach(card=>card.addEventListener('click',()=>openModal(card.dataset.id)));
  }

  /* ---------------- product grid ---------------- */

  function waLink(productName) {
    const text = `Hello RIDDHII GALA, I would like to enquire about the ${productName}.`;
    return `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(text)}`;
  }

  function mediaMarkup(product, sizeClass) {
    if (product.video_url) {
      return `<video src="${product.video_url}" ${sizeClass} muted loop playsinline autoplay></video>`;
    }
    if (product.image_url) {
      return `<img src="${product.image_url}" alt="${product.name}" ${sizeClass} />`;
    }
    return SILHOUETTES[product.art] || SILHOUETTES.dress;
  }

  function galleryMarkup(product) {
    const urls = [];
    if (product.image_url) urls.push({ url: product.image_url, label: "Front" });
    if (product.back_image_url) urls.push({ url: product.back_image_url, label: "Back" });
    if (product.profile_image_url) urls.push({ url: product.profile_image_url, label: "Profile" });
    (Array.isArray(product.image_urls) ? product.image_urls : []).forEach((url, i) => urls.push({ url, label: `View ${i + 1}` }));
    if (!urls.length) return mediaMarkup(product, "");
    if (urls.length === 1) return `<div class="rg-gallery"><img src="${urls[0].url}" alt="${product.name} — ${urls[0].label}" class="zoomable-photo rg-gallery-image"></div>`;
    return `<div class="rg-gallery" data-gallery>
      <div class="rg-gallery-frame">
        <button type="button" class="rg-gallery-arrow rg-gallery-prev" aria-label="Previous image">‹</button>
        <img src="${urls[0].url}" alt="${product.name} — ${urls[0].label}" class="zoomable-photo rg-gallery-image" data-gallery-image>
        <button type="button" class="rg-gallery-arrow rg-gallery-next" aria-label="Next image">›</button>
      </div>
      <div class="rg-gallery-count" data-gallery-count>1 / ${urls.length}</div>
      <div class="rg-gallery-dots" aria-label="Product images">${urls.map((_,i)=>`<button type="button" class="rg-gallery-dot${i===0?' active':''}" data-gallery-dot="${i}" aria-label="Image ${i+1}"></button>`).join('')}</div>
    </div>`;
  }

  async function fetchProducts(filterKey) {
    let query = supabaseClient.from("products").select("*").eq("status", "active");
    if (filterKey === "featured") {
      query = query.eq("featured", true).order("featured_order", { ascending: true, nullsFirst: false }).order("created_at", { ascending: false });
    } else {
      query = query.contains("filters", [filterKey]).order("created_at", { ascending: false });
    }
    const { data, error } = await query;
    if (error) { console.error(error); return []; }
    return data || [];
  }

  let productsCache = [];
  let currentPage = 1;
  const PAGE_SIZE = 15;

  function renderPagination(total) {
    const old = document.getElementById("rg-pagination");
    if (old) old.remove();
    const pages = Math.ceil(total / PAGE_SIZE);
    if (pages <= 1 || !grid) return;
    const nav = document.createElement("nav");
    nav.id = "rg-pagination";
    nav.className = "rg-pagination";
    nav.setAttribute("aria-label", "Collection pages");
    const buttons = [];
    buttons.push(`<button type="button" data-page="prev" ${currentPage===1?'disabled':''}>‹ Previous</button>`);
    for (let p=1;p<=pages;p++) buttons.push(`<button type="button" data-page="${p}" class="${p===currentPage?'active':''}" aria-current="${p===currentPage?'page':'false'}">${p}</button>`);
    buttons.push(`<button type="button" data-page="next" ${currentPage===pages?'disabled':''}>Next ›</button>`);
    nav.innerHTML=buttons.join('');
    grid.parentElement.appendChild(nav);
    nav.querySelectorAll('[data-page]').forEach(btn=>btn.addEventListener('click',()=>{
      const value=btn.dataset.page;
      const pagesCount=Math.ceil(productsCache.length/PAGE_SIZE);
      if(value==='prev') currentPage=Math.max(1,currentPage-1);
      else if(value==='next') currentPage=Math.min(pagesCount,currentPage+1);
      else currentPage=Number(value);
      renderGridPage();
      grid.scrollIntoView({behavior:'smooth',block:'start'});
    }));
  }

  function renderGridPage() {
    if (!grid) return;
    const items=productsCache.slice((currentPage-1)*PAGE_SIZE,currentPage*PAGE_SIZE);
    grid.innerHTML=items.map(p=>`<button class="product-card" type="button" data-id="${p.id}" aria-haspopup="dialog"><span class="card-art">${Array.isArray(p.filters)&&p.filters.includes("new")?'<span class="card-new">New</span>':''}${mediaMarkup(p,"")}</span><span class="card-body"><span class="card-collection">${p.collection||''}</span><h3>${p.name}</h3><p class="card-fabric">${p.fabric||''}</p></span></button>`).join('');
    grid.querySelectorAll('.product-card').forEach(card=>card.addEventListener('click',()=>openModal(card.dataset.id)));
    renderPagination(productsCache.length);
  }

  async function renderGrid(filterKey) {
    if (!grid || NOT_CONFIGURED) return;
    grid.innerHTML='<div class="grid-empty">Loading collection…</div>';
    productsCache=await fetchProducts(filterKey);
    currentPage=1;
    if (!productsCache.length) { grid.innerHTML='<div class="grid-empty">Nothing in this collection yet — check back soon, or ask us directly on WhatsApp.</div>'; renderPagination(0); return; }
    renderGridPage();
  }

  async function setActiveFilter(key) {
    currentFilter=key;
    filterButtons.forEach(btn=>{const active=btn.getAttribute('data-filter')===key;btn.classList.toggle('active',active);btn.setAttribute('aria-pressed',String(active));});
    await renderGrid(key);
  }

  function productHasSize(product) {
    const text=[product.name,product.collection,Array.isArray(product.filters)?product.filters.join(' '):''].join(' ').toLowerCase();
    if (/eyewear|eyeglass|spectacle|spectacles|glasses|frame/.test(text)) return false;
    if (/bag|handbag|clutch|pouch/.test(text)) return false;
    return true;
  }

  function productIsFootwear(product) {
    const text=[product.name,product.collection,Array.isArray(product.filters)?product.filters.join(' '):''].join(' ').toLowerCase();
    return /sandals?|footwear|shoes?|heels?|juttis?|mules?|flats?/.test(text);
  }

  async function openProductFromUrl() {
    const params=new URLSearchParams(window.location.search);
    const slug=params.get('product');
    if (!slug || NOT_CONFIGURED) return;
    const local=productsCache.find(p=>String(p.slug||'').toLowerCase()===slug.toLowerCase());
    if (local) { openModal(local.id); return; }
    const {data,error}=await supabaseClient.from('products').select('*').eq('status','active').eq('slug',slug).maybeSingle();
    if (error || !data) { console.warn('Product slug not found:',slug,error); return; }
    if (!productsCache.some(p=>p.id===data.id)) productsCache.push(data);
    openModal(data.id);
  }

  async function openCollectionFromUrl() {
    const key=new URLSearchParams(window.location.search).get('collection');
    if (!key) return;
    await setActiveFilter(key);
  }

  /* ---------------- modal ---------------- */

  function openModal(id) {
    const product = productsCache.find((p) => p.id === id);
    if (!product || !modal || !modalContent) return;

    const priceHtml = product.sale_price
      ? `<span><strong style="text-decoration:line-through;opacity:.6;margin-right:.5em;font-weight:400;">${product.price || "Price on request"}</strong><strong style="color:var(--maroon);">${product.sale_price}</strong></span>`
      : `<span><strong>${product.price || "Price on request"}</strong></span>`;

    const showWhatsapp = product.whatsapp_enquiry_enabled !== false;
    const showBuyNow = product.buy_now_enabled !== false && !!product.payment_link;
    const variants = Array.isArray(product.variants) ? product.variants : [];
    const variantHtml = variants.length ? `<div class="product-options" style="display:grid;gap:.8rem;margin:1rem 0;">${variants.map((v,i)=>`<label style="display:grid;gap:.35rem;font-size:.85rem;"><span><strong>${v.name || `Option ${i+1}`}</strong></span><select data-checkout-variant="${i}" style="padding:.7rem;border:1px solid var(--line-strong);background:var(--paper);">${(Array.isArray(v.values)?v.values:[]).map(x=>`<option>${x}</option>`).join("")}</select></label>`).join("")}</div>` : "";
    const needsSize = productHasSize(product);
    const footwear = productIsFootwear(product);
    const sizeValues = footwear ? ["5","6","7","8","9","10","11"] : ["XS","S","M","L","XL","2XL"];
    const sizeChartHtml = needsSize ? `<div class="product-size-picker" style="margin:1rem 0;">
      <div style="font-size:.85rem;margin-bottom:.45rem;"><strong>Size</strong></div>
      <div class="size-choice-group" role="radiogroup" aria-label="Choose size">
        ${sizeValues.map(x => `<button type="button" class="size-choice" data-size="${x}" aria-pressed="false">${x}</button>`).join("")}
        ${!footwear ? `<button type="button" class="size-choice" data-size="Custom Size" aria-pressed="false">Custom Size</button>` : ""}
      </div>
      <p class="muted" style="font-size:.78rem;margin:.45rem 0 0;">Choose your size${footwear?'':' or Custom Size'}, or view the size chart first.</p>
    </div>
    <button type="button" class="button button-soft size-chart-button" id="view-size-chart" aria-label="View Size Chart">View Size Chart</button>` : "";
    const mtmHtml = product.made_to_measure_enabled !== false ? `<p style="margin:.8rem 0;font-size:.85rem;color:var(--ink-soft);"><strong>Made to Measure:</strong> Have a special measurement or fit requirement? <a href="index.html#contact" style="color:var(--maroon);">Tell us before ordering</a>.</p>` : "";
    const keyFeatures = Array.isArray(product.key_features) ? product.key_features.filter(Boolean).slice(0, 6) : [];
    const keyFeaturesHtml = keyFeatures.length ? `<div style="margin:1rem 0;"><strong style="font-size:.9rem;">Key Features</strong><ol style="margin:.45rem 0 0 1.2rem;padding:0;color:var(--ink-soft);font-size:.86rem;">${keyFeatures.map(f => `<li style="margin:.25rem 0;">${String(f).replace(/</g,"&lt;")}</li>`).join("")}</ol></div>` : "";

    modalContent.innerHTML = `
      <div class="modal-art">${galleryMarkup(product)}</div>
      <div class="modal-body">
        <span class="card-collection">${product.collection || ""}</span>
        <h3>${product.name}</h3>
        <p>${product.description || ""}</p>
        <div class="modal-meta">
          <span><strong>Fabric:</strong> ${product.fabric || "—"}</span>
          <span><strong>Silhouette:</strong> ${product.silhouette || "—"}</span>
          ${priceHtml}
        </div>
        ${variantHtml}
        <div style="display:flex;gap:.6rem;flex-wrap:wrap;align-items:center;">${sizeChartHtml}${showWhatsapp ? `<a class="button button-dark" href="${waLink(product.name)}" target="_blank" rel="noreferrer">Enquire on WhatsApp</a>` : ""}<a class="button button-soft product-buy-now" href="checkout.html?product=${encodeURIComponent(product.id)}" style="margin-left:0;${showBuyNow ? "" : "display:none;"}">Buy Now</a></div>
        ${keyFeaturesHtml}
        ${mtmHtml}
        <div id="size-chart-overlay" class="size-chart-overlay" hidden role="dialog" aria-modal="true" aria-labelledby="size-chart-title"><div class="size-chart-panel"><button class="close" type="button" id="close-size-chart" aria-label="Close size chart">×</button><div class="size-chart-content">${product.size_chart_url ? `<h3 id="size-chart-title">Size Chart</h3><img src="${product.size_chart_url}" alt="Size chart for ${product.name}">` : `<h3 id="size-chart-title">Standard Size Guide</h3><p style="margin-bottom:.8rem;color:var(--ink-soft);font-size:.82rem;">Use this standard guide as a starting point. For the best fit, please contact us for assistance.</p><div class="standard-size-table-wrap"><table class="standard-size-table"><thead><tr><th>Size</th><th>Bust</th><th>Waist</th><th>Hip</th></tr></thead><tbody><tr><td>XS</td><td>32"</td><td>26"</td><td>34"</td></tr><tr><td>S</td><td>34"</td><td>28"</td><td>36"</td></tr><tr><td>M</td><td>36"</td><td>30"</td><td>38"</td></tr><tr><td>L</td><td>38"</td><td>32"</td><td>40"</td></tr><tr><td>XL</td><td>40"</td><td>34"</td><td>42"</td></tr><tr><td>2XL</td><td>42"</td><td>36"</td><td>44"</td></tr></tbody></table></div>`}</div></div></div>
      </div>
    `;

    const gallery = modalContent.querySelector('[data-gallery]');
    if (gallery) {
      const images = [
        ...(product.image_url ? [{url:product.image_url,label:'Front'}] : []),
        ...(product.back_image_url ? [{url:product.back_image_url,label:'Back'}] : []),
        ...(product.profile_image_url ? [{url:product.profile_image_url,label:'Profile'}] : []),
        ...((Array.isArray(product.image_urls)?product.image_urls:[]).map((url,i)=>({url,label:`View ${i+1}`})))
      ];
      let galleryIndex=0;
      const image=gallery.querySelector('[data-gallery-image]'), count=gallery.querySelector('[data-gallery-count]');
      const dots=[...gallery.querySelectorAll('[data-gallery-dot]')];
      const updateGallery=()=>{const item=images[galleryIndex]; image.src=item.url; image.alt=`${product.name} — ${item.label}`; count.textContent=`${galleryIndex+1} / ${images.length}`; dots.forEach((d,i)=>d.classList.toggle('active',i===galleryIndex));};
      gallery.querySelector('.rg-gallery-prev')?.addEventListener('click',()=>{galleryIndex=(galleryIndex-1+images.length)%images.length;updateGallery();});
      gallery.querySelector('.rg-gallery-next')?.addEventListener('click',()=>{galleryIndex=(galleryIndex+1)%images.length;updateGallery();});
      dots.forEach(d=>d.addEventListener('click',()=>{galleryIndex=Number(d.dataset.galleryDot);updateGallery();}));
      let startX=0; gallery.addEventListener('touchstart',e=>{startX=e.changedTouches[0].clientX;},{passive:true}); gallery.addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-startX;if(Math.abs(dx)>40){galleryIndex=(galleryIndex+(dx<0?1:-1)+images.length)%images.length;updateGallery();}},{passive:true});
    }
    modalContent.querySelectorAll(".zoomable-photo").forEach((img) => {
      img.addEventListener("click", () => openLightbox(img.src, img.alt));
    });
    const sizeOverlay = modalContent.querySelector("#size-chart-overlay");
    const sizeBtn = modalContent.querySelector("#view-size-chart");
    const sizeClose = modalContent.querySelector("#close-size-chart");
    const sizeChoices = modalContent.querySelectorAll(".size-choice");
    const buyNowLink = modalContent.querySelector(".product-buy-now");
    sizeChoices.forEach((button) => button.addEventListener("click", () => {
      sizeChoices.forEach((b) => { const active = b === button; b.classList.toggle("selected", active); b.setAttribute("aria-pressed", active ? "true" : "false"); });
      if (buyNowLink) buyNowLink.href = `checkout.html?product=${encodeURIComponent(product.id)}&size=${encodeURIComponent(button.dataset.size || "")}`;
    }));
    if (buyNowLink) {
      buyNowLink.addEventListener("click", (event) => {
        if (!needsSize) return;
        const selected = modalContent.querySelector(".size-choice.selected");
        if (!selected) {
          event.preventDefault();
          const first = modalContent.querySelector(".size-choice");
          if (first) first.focus();
          alert("Please select your size before continuing to checkout.");
        }
      });
    }
    const inlineChart = modalContent.querySelector("#view-size-chart-inline");
    if (inlineChart && sizeBtn) inlineChart.addEventListener("click", (event) => { event.preventDefault(); sizeBtn.click(); });

    if (sizeOverlay && sizeBtn) {
      const closeSizeChart = () => { sizeOverlay.hidden = true; document.body.classList.remove("size-chart-open"); };
      sizeBtn.addEventListener("click", (event) => { event.preventDefault(); event.stopPropagation(); sizeOverlay.hidden = false; document.body.classList.add("size-chart-open"); });
      if (sizeClose) sizeClose.addEventListener("click", (event) => { event.preventDefault(); event.stopPropagation(); closeSizeChart(); });
      sizeOverlay.addEventListener("click", (event) => { if (event.target === sizeOverlay) closeSizeChart(); });
      document.addEventListener("keydown", (event) => { if (event.key === "Escape" && !sizeOverlay.hidden) closeSizeChart(); }, { once: true });
    }

    if (typeof modal.showModal === "function") {
      modal.showModal();
    } else {
      modal.setAttribute("open", "");
    }
  }

  function closeModal() {
    if (!modal) return;
    if (typeof modal.close === "function") modal.close();
    else modal.removeAttribute("open");
  }

  modalClose?.addEventListener("click", closeModal);
  modal?.addEventListener("click", (e) => {
    if (e.target === modal) closeModal();
  });

  /* ---------------- mobile sidebar ---------------- */

  function openSidebar() {
    sidebar?.classList.add("open");
    menuToggle?.setAttribute("aria-expanded", "true");
  }
  function closeSidebar() {
    sidebar?.classList.remove("open");
    menuToggle?.setAttribute("aria-expanded", "false");
  }
  function closeSidebarOnMobile() {
    if (window.matchMedia("(max-width: 960px)").matches) closeSidebar();
  }

  menuToggle?.addEventListener("click", () => {
    const isOpen = sidebar?.classList.contains("open");
    if (isOpen) closeSidebar();
    else openSidebar();
  });

  document.addEventListener("click", (e) => {
    if (!sidebar?.classList.contains("open")) return;
    const target = e.target;
    if (sidebar.contains(target) || menuToggle?.contains(target)) return;
    closeSidebar();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeSidebar();
  });

  /* ---------------- active nav link on scroll ---------------- */

  function wireScrollHighlighting() {
    navLinks = Array.from(document.querySelectorAll(".nav-link"));
    navLinks.forEach((link) => link.addEventListener("click", closeSidebarOnMobile));

    const sectionIds = navLinks
      .map((link) => link.getAttribute("href"))
      .filter((href) => href && href.startsWith("#"))
      .map((href) => href.slice(1));
    const sections = sectionIds.map((id) => document.getElementById(id)).filter(Boolean);

    if ("IntersectionObserver" in window && sections.length) {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (!entry.isIntersecting) return;
            const id = entry.target.id;
            navLinks.forEach((link) => {
              link.classList.toggle("active", link.getAttribute("href") === `#${id}`);
            });
          });
        },
        { rootMargin: "-40% 0px -55% 0px", threshold: 0 }
      );
      sections.forEach((section) => observer.observe(section));
    }
  }

  /* ---------------- realtime: new/edited/deleted items show up live ---------------- */

  function subscribeRealtime() {
    supabaseClient
      .channel("public:products")
      .on("postgres_changes", { event: "*", schema: "public", table: "products" }, () => renderGrid(currentFilter))
      .subscribe();

    const rerenderNav = async () => {
      const data = await fetchCategoryData();
      renderSidebarNav(data);
      wireFilterButtons();
      filterButtons.forEach((btn) => btn.classList.toggle("active", btn.getAttribute("data-filter") === currentFilter));
    };

    supabaseClient
      .channel("public:categories")
      .on("postgres_changes", { event: "*", schema: "public", table: "category_groups" }, rerenderNav)
      .on("postgres_changes", { event: "*", schema: "public", table: "category_children" }, rerenderNav)
      .on("postgres_changes", { event: "*", schema: "public", table: "standalone_filters" }, rerenderNav)
      .on("postgres_changes", { event: "*", schema: "public", table: "coming_soon" }, rerenderNav)
      .subscribe();

    supabaseClient
      .channel("public:reviews")
      .on("postgres_changes", { event: "*", schema: "public", table: "reviews" }, () => renderTestimonials())
      .subscribe();
  }

  /* ---------------- init ---------------- */

  async function init() {
    wireScrollHighlighting();
    wireEnquiryForm();
    applyWhatsappLinks(); // apply the fallback number immediately, refined once settings load
    if (NOT_CONFIGURED) return;

    const categoryData = await fetchCategoryData();
    renderSidebarNav(categoryData);
    wireFilterButtons();
    await setActiveFilter(currentFilter);
    await loadSiteSettings();
    await renderTestimonials();
    await openProductFromUrl();
    subscribeRealtime();
  }

  init();
})();
