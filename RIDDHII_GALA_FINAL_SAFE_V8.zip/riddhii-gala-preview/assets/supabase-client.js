/* RIDDHII GALA — Supabase connection */
const SUPABASE_URL = "https://ggijuoryszgyhcevxydq.supabase.co";
const SUPABASE_PUBLISHABLE_KEY =
  "sb_publishable_klsqLfyUzTpkH3jvsW7w3g_IJosL9jj";
const supabaseClient = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_PUBLISHABLE_KEY
);
