/* ==========================================================================
   RIDDHII GALA — placeholder line-art silhouettes
   Used as a fallback icon whenever a product has no uploaded photo.
   Kept as a static file since these are fixed design assets, not content
   you manage via the admin.
   ========================================================================== */
const SILHOUETTES = {
  dress: `<svg viewBox="0 0 120 160" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M50 8 Q60 2 70 8 L74 22 Q60 30 46 22 Z"/><path d="M46 22 L36 46 Q30 60 34 78 L26 150 Q60 158 94 150 L86 78 Q90 60 84 46 L74 22"/><path d="M46 22 L58 40 L60 60 L62 40 L74 22"/></svg>`,
  suit: `<svg viewBox="0 0 120 160" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M46 10 L60 20 L74 10 L88 24 L80 40 L74 32 L74 150 L46 150 L46 32 L40 40 L32 24 Z"/><path d="M60 20 L52 34 L60 46 L68 34 Z"/><path d="M46 32 L36 60 M74 32 L84 60"/></svg>`,
  kids: `<svg viewBox="0 0 120 160" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M52 14 Q60 8 68 14 L72 26 Q60 32 48 26 Z"/><path d="M48 26 L38 42 Q34 52 38 62 L34 118 Q60 126 86 118 L82 62 Q86 52 82 42 L72 26"/><path d="M40 100 L34 118 M80 100 L86 118"/></svg>`,
  lehenga: `<svg viewBox="0 0 120 160" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M48 10 Q60 4 72 10 L76 30 Q60 38 44 30 Z"/><path d="M44 30 L36 46 L84 46 L76 30"/><path d="M32 150 Q60 158 88 150 L84 46 Q60 40 36 46 Z"/><path d="M50 46 Q60 90 50 150 M70 46 Q60 90 70 150"/><path d="M22 60 Q10 90 22 140" stroke-dasharray="2 5"/></svg>`,
  eyewear: `<svg viewBox="0 0 160 90" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="14" y="26" width="46" height="38" rx="8"/><rect x="100" y="26" width="46" height="38" rx="8"/><path d="M60 40 Q80 28 100 40"/><path d="M14 40 L2 34 M146 40 L158 34"/></svg>`,
};
