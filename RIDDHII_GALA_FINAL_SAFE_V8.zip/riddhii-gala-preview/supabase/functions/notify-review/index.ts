// RIDDHII GALA — notify-review
//
// Sends you an email whenever a new review is submitted for approval.
// Same setup as notify-enquiry: deploy via Supabase Dashboard → Edge
// Functions, paste this in, set the same two secrets (they're shared
// across functions in one project, so if you already set these for
// notify-enquiry, this one is ready as soon as it's deployed):
//   RESEND_API_KEY   — from resend.com
//   NOTIFY_TO_EMAIL  — where you want to receive these

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
  const NOTIFY_TO_EMAIL = Deno.env.get("NOTIFY_TO_EMAIL");

  if (!RESEND_API_KEY || !NOTIFY_TO_EMAIL) {
    return new Response(
      JSON.stringify({ ok: false, error: "Email notifications aren't configured yet (missing RESEND_API_KEY or NOTIFY_TO_EMAIL secret)." }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ ok: false, error: "Invalid request body" }), { status: 400 });
  }

  const name = String(body.name || "").slice(0, 200);
  const rating = Number(body.rating) || 0;
  const review = String(body.review || "").slice(0, 4000);

  if (!name || !review) {
    return new Response(JSON.stringify({ ok: false, error: "Missing required fields" }), { status: 400 });
  }

  const html = `
    <h2>New review awaiting approval — RIDDHII GALA</h2>
    <p><strong>Name:</strong> ${escapeHtml(name)}</p>
    <p><strong>Rating:</strong> ${"★".repeat(Math.max(0, Math.min(5, rating)))}${"☆".repeat(5 - Math.max(0, Math.min(5, rating)))}</p>
    <p><strong>Review:</strong></p>
    <p>${escapeHtml(review).replace(/\n/g, "<br>")}</p>
    <p>Go to Admin → Reviews to publish or delete it.</p>
  `;

  const resendRes = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: "RIDDHII GALA <onboarding@resend.dev>",
      to: NOTIFY_TO_EMAIL,
      subject: `New review from ${name}`,
      html,
    }),
  });

  if (!resendRes.ok) {
    const errText = await resendRes.text();
    return new Response(JSON.stringify({ ok: false, error: `Resend error: ${errText}` }), { status: 502 });
  }

  return new Response(JSON.stringify({ ok: true }), { status: 200, headers: { "Content-Type": "application/json" } });
});

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
