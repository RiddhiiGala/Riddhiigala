// RIDDHII GALA — notify-enquiry
//
// Sends you an email whenever a new enquiry is submitted. Deploy this
// via the Supabase Dashboard (Edge Functions → Deploy a new function),
// paste this file in, and set two secrets before it'll work:
//   RESEND_API_KEY   — from resend.com (free tier is enough to start)
//   NOTIFY_TO_EMAIL  — the email address that should receive enquiries
//
// This function never runs on its own — the site calls it right after
// an enquiry is saved to Supabase. If this call fails for any reason,
// the enquiry itself is already safely saved in the database either way;
// this is just the notification on top.

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
  const NOTIFY_TO_EMAIL = Deno.env.get("NOTIFY_TO_EMAIL");

  if (!RESEND_API_KEY || !NOTIFY_TO_EMAIL) {
    // Not configured yet — fail quietly rather than pretending this worked.
    return new Response(
      JSON.stringify({ ok: false, error: "Email notifications aren't configured yet (missing RESEND_API_KEY or NOTIFY_TO_EMAIL secret)." }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ ok: false, error: "Invalid request body" }), { status: 400 });
  }

  const name = String(body.name || "").slice(0, 200);
  const whatsapp = String(body.whatsapp || "").slice(0, 50);
  const email = String(body.email || "").slice(0, 200);
  const message = String(body.message || "").slice(0, 4000);

  if (!name || !whatsapp || !message) {
    return new Response(JSON.stringify({ ok: false, error: "Missing required fields" }), { status: 400 });
  }

  const html = `
    <h2>New enquiry — RIDDHII GALA</h2>
    <p><strong>Name:</strong> ${escapeHtml(name)}</p>
    <p><strong>WhatsApp:</strong> ${escapeHtml(whatsapp)}</p>
    <p><strong>Email:</strong> ${escapeHtml(email || "—")}</p>
    <p><strong>Message:</strong></p>
    <p>${escapeHtml(message).replace(/\n/g, "<br>")}</p>
  `;

  const resendRes = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      // onboarding@resend.dev works immediately with no setup, but only
      // delivers to the email you signed up to Resend with. Once you
      // verify your own domain in Resend, switch this to something like
      // "RIDDHII GALA <enquiries@riddhiigala.com>".
      from: "RIDDHII GALA <onboarding@resend.dev>",
      to: NOTIFY_TO_EMAIL,
      subject: `New enquiry from ${name}`,
      html,
      reply_to: email || undefined,
    }),
  });

  if (!resendRes.ok) {
    const errText = await resendRes.text();
    return new Response(JSON.stringify({ ok: false, error: `Resend error: ${errText}` }), { status: 502 });
  }

  return new Response(JSON.stringify({ ok: true }), { status: 200, headers: { "Content-Type": "application/json" } });
});

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
