# Pinterest Catalog Setup — RIDDHII GALA

Two files:

1. **product.html** — an individual product page. Upload it to the root of your
   site (next to your existing index.html / admin.html), so it's reachable at
   `https://riddhiigala.in/product.html?id=SOME-PRODUCT-ID`. It reads the `id`
   from the URL, fetches that product from your `products` table, and displays
   it. Every one of your 14 products now has its own shareable, unique link —
   e.g. for sharing in ads or DMs, not just for Pinterest.

   Before uploading, open the file and update this line near the bottom with
   your real WhatsApp Business number (country code, no `+`, no spaces):
   ```
   const WHATSAPP_NUMBER = "91XXXXXXXXXX";
   ```

2. **pinterest-feed/index.ts** — a Supabase Edge Function that turns your
   `products` table into the CSV file Pinterest needs, refreshed live every
   time Pinterest checks it (no need to regenerate anything by hand).

## Deploying the Edge Function

You'll need the Supabase CLI. From your project folder:

```bash
npm install -g supabase
supabase login
supabase link --project-ref ggijuoryszgyhcevxydq
supabase functions deploy pinterest-feed --no-verify-jwt
```

That last command will print your function's live URL. It will look like:

```
https://ggijuoryszgyhcevxydq.supabase.co/functions/v1/pinterest-feed
```

That's the exact URL to paste into **Pinterest Catalogs → Add data source**,
with file format set to **CSV**.

## After deploying

1. Visit the feed URL in your browser — you should see plain CSV text with
   one row per product. If a product is missing `name`, `image_url`, or
   `price`, it's silently skipped (Pinterest would reject it anyway), so
   double check your row count matches your expectations.
2. In Pinterest: **Catalogs → Get Started → Add data source**, paste the URL,
   choose CSV, no password needed, and submit.
3. Pinterest will email you validation results within 24–48 hours. Common
   flags: missing Google Product Category (optional to add later), or a
   product missing an image.

## Notes

- Price is stored in your table as text like `₹20,000/-`. The function strips
  everything but digits and outputs it as `20000.00 INR`, which is the format
  Pinterest requires. Double check a few rows after deploying to make sure
  this parsed correctly for oddly formatted prices.
- All products are marked `"in stock"` by default, since there's no
  stock/quantity field in your table yet. If you add one later, tell me and
  I'll wire it in.
