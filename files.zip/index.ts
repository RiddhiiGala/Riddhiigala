// Supabase Edge Function: pinterest-feed
// Generates a CSV product feed for Pinterest Catalogs from the `products` table.
//
// Deploy with:
//   supabase functions deploy pinterest-feed --no-verify-jwt
//
// Once deployed, your feed URL will be:
//   https://ggijuoryszgyhcevxydq.supabase.co/functions/v1/pinterest-feed
//
// That's the URL you paste into Pinterest Catalogs > Add data source (format: CSV).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Update this if your live site's product page URL pattern changes.
const PRODUCT_PAGE_BASE = "https://riddhiigala.in/product.html?id=";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

function csvEscape(value: string): string {
  if (value == null) return "";
  const str = String(value);
  if (/[",\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

// Turns "₹20,000/-" into "20000.00 INR" (the format Pinterest expects)
function parsePrice(raw: string | null): string {
  if (!raw) return "";
  const digits = raw.replace(/[^\d.]/g, "");
  if (!digits) return "";
  const num = parseFloat(digits);
  if (isNaN(num)) return "";
  return `${num.toFixed(2)} INR`;
}

Deno.serve(async () => {
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  const { data: products, error } = await supabase
    .from("products")
    .select("id, name, description, price, image_url, collection, fabric, silhouette");

  if (error) {
    return new Response(`Error fetching products: ${error.message}`, { status: 500 });
  }

  const headers = [
    "id",
    "title",
    "description",
    "availability",
    "condition",
    "price",
    "link",
    "image_link",
    "brand",
    "product_type",
  ];

  const rows = (products || [])
    // Skip incomplete rows Pinterest would reject anyway
    .filter((p) => p.name && p.image_url && p.price)
    .map((p) => {
      const row = [
        p.id,
        p.name,
        p.description || p.name,
        "in stock",
        "new",
        parsePrice(p.price),
        `${PRODUCT_PAGE_BASE}${encodeURIComponent(p.id)}`,
        p.image_url,
        "RIDDHII GALA",
        [p.collection, p.fabric, p.silhouette].filter(Boolean).join(" / "),
      ];
      return row.map(csvEscape).join(",");
    });

  const csv = [headers.join(","), ...rows].join("\n");

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Cache-Control": "public, max-age=3600",
    },
  });
});
